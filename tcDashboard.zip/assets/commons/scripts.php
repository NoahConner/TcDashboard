<!-- smoth Scrollbar -->
<script src="<?php  echo $backLink; ?>assets/js/smooth-scrollbar.js"  crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<!-- Anime -->
<script src="<?php  echo $backLink; ?>assets/js/anime.min.js"></script>
<!-- Wow -->
<script src="<?php  echo $backLink; ?>assets/js/wow.min.js" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<!-- bootstrap -->
<script src="<?php  echo $backLink; ?>assets/js/bootstrap.bundle.min.js"></script>
<!-- main js -->
<script src="<?php  echo $backLink; ?>assets/js/main.js"></script>